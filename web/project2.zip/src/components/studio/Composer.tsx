import React, { useCallback, useEffect, useLayoutEffect, useRef } from 'react';
import { Plus, Square, X } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { IconButton } from '../ui/IconButton';

/** Past this height the field scrolls internally instead of eating the conversation above it. */
const MAX_HEIGHT = 180;

export interface ComposerAttachment {
  name: string;
  sizeFormatted: string;
  type: string;
}

const formatSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

/**
 * The composer.
 *
 * One container, three affordances: attach, type, send. Everything else the AI can be told lives
 * in the conversation, so the composer stays out of the way of the thing the user is reading.
 *
 * Attachments are deliberately local state that is handed to `onSubmit` rather than uploaded here:
 * the file belongs to the turn it was attached to, so it must not outlive that message.
 */
export const Composer: React.FC<{
  value: string;
  onChange: (value: string) => void;
  onSubmit: (value: string, attachments: ComposerAttachment[]) => void;
  onStop?: () => void;
  placeholder: string;
  isBusy?: boolean;
  autoFocus?: boolean;
  /** Lets the parent focus this exact field; the chat renders two composers when preview is open. */
  inputRef?: React.Ref<HTMLTextAreaElement>;
  testId?: string;
  /** Set while the user is correcting an earlier message, so the re-send is never ambiguous. */
  editing?: { label: string; onCancel: () => void } | null;
}> = ({ value, onChange, onSubmit, onStop, placeholder, isBusy, autoFocus, inputRef, testId, editing }) => {
  const { t } = useWorkspace();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [attachments, setAttachments] = React.useState<ComposerAttachment[]>([]);

  const resize = useCallback(() => {
    const node = textareaRef.current;
    if (!node) return;
    node.style.height = 'auto';
    node.style.height = `${Math.min(node.scrollHeight, MAX_HEIGHT)}px`;
    // Once the field is capped, scroll the overflow rather than letting it push the transcript off.
    node.style.overflowY = node.scrollHeight > MAX_HEIGHT ? 'auto' : 'hidden';
  }, []);

  // `useLayoutEffect` so the field never paints for a frame at its previous height.
  useLayoutEffect(resize, [value, resize]);

  useEffect(() => {
    if (autoFocus) textareaRef.current?.focus();
  }, [autoFocus]);

  const submit = () => {
    const text = value.trim();
    if (!text || isBusy) return;
    onSubmit(text, attachments);
    setAttachments([]);
    setTimeout(resize, 0);
  };

  return (
    <div
      className="rounded-2xl border border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)] transition-colors focus-within:border-[var(--md-sys-color-outline)]"
      data-testid={testId}
    >
      {editing && (
        <div className="flex items-center gap-2 border-b border-[var(--md-sys-color-outline-variant)] px-3 py-1.5">
          <span className="text-[11px] font-medium text-[var(--md-sys-color-primary)]">
            {editing.label}
          </span>
          <span className="min-w-0 flex-1 truncate text-[11px] text-[var(--md-sys-color-on-surface-variant)]">
            {value}
          </span>
          <IconButton label={t.removeAttachment} onClick={editing.onCancel}>
            <X size={13} />
          </IconButton>
        </div>
      )}

      {attachments.length > 0 && (
        <ul
          className="flex flex-wrap gap-1.5 px-3 pt-2.5"
          data-testid="composer-attachments"
          aria-label={t.attachFilesLabel}
        >
          {attachments.map((file, index) => (
            <li
              key={`${file.name}-${index}`}
              data-testid="attachment-chip"
              className="inline-flex max-w-[14rem] items-center gap-1.5 rounded-md border border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface)] py-0.5 pe-0.5 ps-2 text-[11px] text-[var(--md-sys-color-on-surface)]"
            >
              <span className="truncate">{file.name}</span>
              <IconButton
                label={`${t.removeAttachment} ${file.name}`}
                onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== index))}
              >
                <X size={11} />
              </IconButton>
            </li>
          ))}
        </ul>
      )}

      <div className="flex items-end gap-1 p-1.5">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          aria-hidden="true"
          tabIndex={-1}
          onChange={(e) => {
            setAttachments((prev) => [
              ...prev,
              ...Array.from(e.target.files ?? []).map((file) => ({
                name: file.name,
                sizeFormatted: formatSize(file.size),
                type: file.type || 'application/octet-stream',
              })),
            ]);
            e.target.value = '';
          }}
        />
        <IconButton
          label={t.attachFilesLabel}
          onClick={() => fileInputRef.current?.click()}
          testId="composer-attach"
          size="md"
        >
          <Plus size={18} />
        </IconButton>

        <textarea
          ref={(node) => {
            textareaRef.current = node;
            if (typeof inputRef === 'function') inputRef(node);
            else if (inputRef) (inputRef as React.MutableRefObject<HTMLTextAreaElement | null>).current = node;
          }}
          rows={1}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            // Enter sends, Shift+Enter breaks the line — IME composition must win, or typing in
            // Persian or Japanese would send a half-finished word.
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              submit();
            }
          }}
          placeholder={placeholder}
          aria-label={placeholder}
          data-testid="composer-input"
          className="my-1.5 min-h-6 min-w-0 flex-1 resize-none bg-transparent px-1 py-1.5 text-[14px] leading-6 text-[var(--md-sys-color-on-surface)] outline-none placeholder:text-[var(--md-sys-color-on-surface-variant)]"
        />

        {isBusy && onStop ? (
          <IconButton label={t.stop} onClick={onStop} testId="composer-stop" size="md">
            <Square size={13} fill="currentColor" />
          </IconButton>
        ) : (
          <IconButton
            label={t.send}
            onClick={submit}
            disabled={!value.trim()}
            variant="filled"
            testId="composer-send"
            size="md"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.4"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M12 19V5M5 12l7-7 7 7" />
            </svg>
          </IconButton>
        )}
      </div>
    </div>
  );
};