import React, { useState } from 'react';
import { Bot as BotGlyph, Check, ChevronDown, Clock, Play, SquarePen } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { IconButton } from '../ui/IconButton';
import { Menu, MenuItem } from '../ui/Menu';

/**
 * Which kind of thing this session is building.
 *
 * The future modes are listed so the shape of the product is honest, and they are inert: a menu
 * entry that says "Coming soon" and does nothing is a promise, not a feature. Designing a builder
 * the product does not have is how interfaces end up full of half-features.
 */
const ModeSelector: React.FC = () => {
  const { t } = useWorkspace();
  const [open, setOpen] = useState(false);
  const anchor = React.useRef<HTMLDivElement>(null);

  return (
    <div className="relative" ref={anchor}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
        data-testid="mode-indicator"
        className="flex h-8 cursor-pointer items-center gap-1.5 rounded-lg px-2 text-[13px] font-medium text-[var(--md-sys-color-on-surface)] transition-colors hover:bg-[var(--md-sys-color-state-hover)]"
      >
        <BotGlyph size={15} className="text-[var(--md-sys-color-on-surface-variant)]" />
        {t.botMode}
        <ChevronDown size={13} className="text-[var(--md-sys-color-on-surface-variant)]" />
      </button>

      <Menu
        open={open}
        anchorRef={anchor}
        onClose={() => setOpen(false)}
        label={t.modeMenuTitle}
        width={196}
      >
        <MenuItem label={t.botMode} selected onClick={() => setOpen(false)} icon={<BotGlyph size={13} />} />
        <MenuItem
          label={t.tools}
          disabled
          supporting={t.comingSoon}
          icon={<Clock size={13} />}
          testId="mode-coming-soon"
        />
      </Menu>
    </div>
  );
};

/**
 * The top app bar.
 *
 * Title, mode, and two actions. There is no navigation here and no breadcrumbs: the conversation
 * is the whole navigation, and a second one on top of it would only compete.
 */
export const ChatHeader: React.FC = () => {
  const { t, startNewChat, artifact, isPreviewOpen, openPreview, closePreview } = useWorkspace();

  return (
    <header
      className="flex h-12 shrink-0 items-center gap-2 border-b border-[var(--md-sys-color-outline-variant)] px-3 sm:px-4"
      data-testid="app-bar"
    >
      <span className="text-[14px] font-semibold tracking-tight text-[var(--md-sys-color-on-surface)]">
        {t.appTitle}
      </span>
      <ModeSelector />

      <div className="flex-1" />

      <button
        type="button"
        onClick={() => startNewChat()}
        data-testid="new-chat"
        className="hidden h-8 cursor-pointer items-center gap-1.5 rounded-lg px-2 text-[13px] font-medium text-[var(--md-sys-color-on-surface-variant)] transition-colors hover:bg-[var(--md-sys-color-state-hover)] sm:flex"
      >
        <SquarePen size={14} />
        {t.newChatLabel}
      </button>

      {/* Rendered only once there is something to run: a permanently disabled control in the app
          bar is noise that promises a capability the session has not earned yet. */}
      {artifact && (
        <IconButton
          label={isPreviewOpen ? t.collapsePreview : t.previewBot}
          onClick={isPreviewOpen ? closePreview : openPreview}
          variant="tonal"
          size="md"
          testId="toggle-preview"
        >
          {isPreviewOpen ? <Check size={16} /> : <Play size={15} />}
        </IconButton>
      )}
    </header>
  );
};