import React from 'react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { UnifiedSidebar } from '../navigation/UnifiedSidebar';
import { CommandPalette } from '../search/CommandPalette';

/**
 * Layout for every authenticated page: the primary sidebar, the routed viewport
 * and the global command palette. Which page renders inside the viewport is the
 * router's decision, not this component's.
 */
export const AppShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isRTL } = useWorkspace();

  return (
    <div
      className="flex h-screen w-screen overflow-hidden bg-[var(--md-sys-color-surface)] text-[var(--md-sys-color-on-surface)]"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <UnifiedSidebar />

      <main className="flex-1 h-full overflow-hidden relative">{children}</main>

      <CommandPalette />
    </div>
  );
};
