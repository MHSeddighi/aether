import React from 'react';

/**
 * The minimum markdown an assistant answer actually needs.
 *
 * A full markdown library would be more code than the interface. This handles the four things the
 * AI genuinely emits — paragraphs, fenced code, bullet and numbered lists, inline emphasis, inline
 * code and links — and passes everything else through as plain text.
 *
 * Nothing is injected as HTML: the parser only ever produces React elements, so a response
 * containing `<script>` renders as the literal characters the user can see, and a `javascript:`
 * link can never become an anchor.
 */

/** Only these schemes may reach an `href`. Anything else renders as inert text. */
const SAFE_SCHEME = /^(https?:|mailto:)/i;

const INLINE = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*\n]+\*|\[[^\]]+\]\([^)\s]+\))/g;

/** Splits one line into text runs and the inline spans above. */
const parseInline = (text: string, keyPrefix: string): React.ReactNode[] =>
  text.split(INLINE).filter((part) => part !== '').map((part, index) => {
    const key = `${keyPrefix}-${index}`;

    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code
          key={key}
          className="rounded border border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container)] px-1 py-px font-mono text-[0.85em] text-[var(--md-sys-color-on-surface)]"
        >
          {part.slice(1, -1)}
        </code>
      );
    }

    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={key} className="font-semibold text-[var(--md-sys-color-on-surface)]">
          {part.slice(2, -2)}
        </strong>
      );
    }

    const italic = part.startsWith('*') && part.endsWith('*') && part.length > 2;
    if (italic) {
      return <em key={key}>{part.slice(1, -1)}</em>;
    }

    const link = /^\[([^\]]+)\]\(([^)\s]+)\)$/.exec(part);
    if (link) {
      const [, label, href] = link;
      if (!SAFE_SCHEME.test(href)) return <React.Fragment key={key}>{label}</React.Fragment>;
      return (
        <a
          key={key}
          href={href}
          target="_blank"
          // `noopener` is what stops the opened page reaching back through `window.opener`.
          rel="noopener noreferrer"
          className="text-[var(--md-sys-color-primary)] underline decoration-[var(--md-sys-color-primary)]/40 underline-offset-2 transition-colors hover:decoration-[var(--md-sys-color-primary)]"
        >
          {label}
        </a>
      );
    }

    return <React.Fragment key={key}>{part}</React.Fragment>;
  });

const BulletList: React.FC<{ items: string[]; ordered?: boolean; start: number }> = ({
  items,
  ordered,
  start,
}) => {
  const List = ordered ? 'ol' : 'ul';
  return (
    <List
      start={ordered ? start : undefined}
      className={`my-2 space-y-1 ps-5 text-[var(--md-sys-color-on-surface)] ${
        ordered ? 'list-decimal' : 'list-disc'
      } marker:text-[var(--md-sys-color-on-surface-variant)]`}
    >
      {items.map((item, index) => (
        <li key={index} className="ps-0.5 leading-6">
          {parseInline(item, `li-${index}`)}
        </li>
      ))}
    </List>
  );
};

/** `#` … `######`, and the model reaches for these constantly, so they cannot render literally. */
const HEADING = /^(#{1,6})\s+(.*)$/;

const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => (
  <pre
    data-language={language}
    className="my-2.5 overflow-x-auto rounded-lg border border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)] px-3 py-2.5 font-mono text-[12px] leading-5 text-[var(--md-sys-color-on-surface)]"
  >
    <code>{code}</code>
  </pre>
);

export const RichText: React.FC<{ content: string; testId?: string }> = ({ content, testId }) => {
  const lines = content.split('\n');
  const blocks: React.ReactNode[] = [];

  let paragraph: string[] = [];
  let bullets: string[] = [];
  let ordered = false;
  let orderedStart = 1;

  const flushParagraph = () => {
    if (paragraph.length === 0) return;
    const text = paragraph.join('\n');
    // Soft line breaks inside a paragraph are line breaks, not paragraph breaks: the model streams
    // short sentences on separate lines constantly, and collapsing them into one paragraph makes
    // short answers look like a wall.
    blocks.push(
      <p key={`p-${blocks.length}`} className="my-2 leading-7 first:mt-0 last:mb-0">
        {parseInline(text, `p-${blocks.length}`)}
      </p>
    );
    paragraph = [];
  };

  const flushList = () => {
    if (bullets.length === 0) return;
    blocks.push(
      <BulletList key={`l-${blocks.length}`} items={bullets} ordered={ordered} start={orderedStart} />
    );
    bullets = [];
  };

  const flushAll = () => {
    flushParagraph();
    flushList();
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const fence = /^```(\w*)\s*$/.exec(line);
    if (fence) {
      flushAll();
      const body: string[] = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i])) body.push(lines[i++]);
      blocks.push(<CodeBlock key={`c-${blocks.length}`} code={body.join('\n')} language={fence[1]} />);
      continue;
    }

    const heading = HEADING.exec(line);
    if (heading) {
      flushAll();
      // Three visual weights only. Beyond that, headings stop being a hierarchy and start being
      // a font-size ladder, which is exactly the "decorative" failure mode to avoid in a transcript.
      const level = Math.min(heading[1].length, 3);
      blocks.push(
        <p
          key={`h-${blocks.length}`}
          className={`mt-5 mb-1.5 font-semibold text-[var(--md-sys-color-on-surface)] first:mt-0 ${
            level === 1 ? 'text-[17px]' : level === 2 ? 'text-[15px]' : 'text-sm'
          }`}
        >
          {parseInline(heading[2], `h-${blocks.length}`)}
        </p>
      );
      continue;
    }

    const bullet = /^\s*[-*•]\s+(.*)$/.exec(line);
    const numbered = /^\s*\d+[.)]\s+(.*)$/.exec(line);
    if (bullet || numbered) {
      flushParagraph();
      const isOrdered = Boolean(numbered);
      if (bullets.length > 0 && isOrdered !== ordered) flushList();
      if (bullets.length === 0) {
        ordered = isOrdered;
        const start = numbered ? Number(/^\s*(\d+)/.exec(line)?.[1] ?? 1) : 1;
        orderedStart = Number.isFinite(start) ? start : 1;
      }
      bullets.push((bullet ? bullet[1] : numbered![1]).trim());
      continue;
    }

    if (line.trim() === '') {
      flushAll();
      continue;
    }

    flushList();
    paragraph.push(line);
  }

  flushAll();

  return (
    <div className="text-[14px] break-words whitespace-pre-wrap" data-testid={testId}>
      {blocks}
    </div>
  );
};