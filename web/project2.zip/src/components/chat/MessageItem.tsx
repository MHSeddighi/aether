import React, { useState } from 'react';
import { Check, ChevronRight, Copy, MoreHorizontal, Pencil, RefreshCw, X } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { ChatMessage } from '../../types/agent';
import { IconButton } from '../ui/IconButton';
import { Menu, MenuItem } from '../ui/Menu';
import { RichText } from './RichText';

/**
 * The actions that apply to a message, revealed on hover.
 *
 * Hidden by default and always reachable: on a pointer device they fade in on hover, and
 * `focus-within` means a keyboard user tabbing through the transcript gets the same row. Without
 * the `focus-within` half, the hover-only rule would put the controls permanently out of reach.
 */
const ActionRow: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="mt-1 flex items-center gap-0.5 opacity-0 transition-opacity duration-100 focus-within:opacity-100 group-hover:opacity-100">
    {children}
  </div>
);

const CopyButton: React.FC<{ text: string }> = ({ text }) => {
  const { t } = useWorkspace();
  const [copied, setCopied] = useState(false);

  return (
    <IconButton
      label={copied ? t.copied : t.copy}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          // Clipboard access can be denied; the text is still selectable on screen.
        }
      }}
    >
      {copied ? <Check size={13} className="text-[var(--md-sys-color-primary)]" /> : <Copy size={13} />}
    </IconButton>
  );
};

/** The "…" overflow. The low-priority actions that are not worth a permanent button live here. */
const MoreMenu: React.FC<{ onFeedback: (feedback: 'good' | 'bad' | undefined) => void }> = ({
  onFeedback,
}) => {
  const { t } = useWorkspace();
  const [open, setOpen] = useState(false);
  const anchor = React.useRef<HTMLDivElement>(null);

  return (
    <div className="relative" ref={anchor}>
      <IconButton label={t.moreActionsLabel} onClick={() => setOpen((v) => !v)} testId="message-more">
        <MoreHorizontal size={14} />
      </IconButton>
      <Menu open={open} anchorRef={anchor} onClose={() => setOpen(false)} label={t.moreActionsLabel} width={172}>
        <MenuItem
          label={t.goodResponse}
          onClick={() => onFeedback('good')}
          testId="message-feedback-good"
        />
        <MenuItem label={t.badResponse} onClick={() => onFeedback('bad')} testId="message-feedback-bad" />
      </Menu>
    </div>
  );
};

/**
 * What the AI did on the way to its answer.
 *
 * A disclosure, not a log: collapsed to a single line, expandable when the user wants to know what
 * the system touched. Only tool outcomes are surfaced — never the reasoning behind them, which is
 * not the user's business and is not reliably present anyway.
 */
const ExecutionStatus: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const { t } = useWorkspace();
  const [open, setOpen] = useState(false);
  const activity = message.toolActivity ?? [];
  if (activity.length === 0) return null;

  const done = activity.filter((step) => step.status === 'completed').length;

  return (
    <div className="mt-1.5" data-testid="execution-status">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        data-testid="execution-toggle"
        className="flex cursor-pointer items-center gap-1 text-[11px] text-[var(--md-sys-color-on-surface-variant)] transition-colors hover:text-[var(--md-sys-color-on-surface)]"
      >
        <ChevronRight
          size={11}
          className={`transition-transform duration-150 ${open ? 'rotate-90' : ''}`}
        />
        {t.whatChanged}
        <span className="text-[var(--md-sys-color-outline)]">·</span>
        {done}/{activity.length}
      </button>

      {open && (
        <ul className="mt-1.5 space-y-0.5 ps-5" data-testid="execution-list">
          {activity.map((step) => (
            <li
              key={step.name}
              className="flex items-center gap-1.5 text-[11px] text-[var(--md-sys-color-on-surface-variant)]"
            >
              {step.status === 'completed' ? (
                <Check size={11} className="shrink-0 text-[var(--md-sys-color-primary)]" />
              ) : step.status === 'failed' ? (
                <X size={11} className="shrink-0 text-[var(--md-sys-color-error)]" />
              ) : (
                <span
                  className="h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-[var(--md-sys-color-primary)]"
                  aria-hidden="true"
                />
              )}
              <span className="truncate">{step.name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

/**
 * One turn of the conversation.
 *
 * The two senders are told apart by **alignment and weight, not by containers**. The user's request
 * is compact and set apart; the assistant's answer is open editorial text with no frame at all, so
 * the transcript reads as a document rather than a stack of chat bubbles.
 */
export const MessageItem: React.FC<{
  message: ChatMessage;
  onRegenerate: () => void;
  onEdit: (message: ChatMessage) => void;
  onFeedback: (message: ChatMessage, feedback: 'good' | 'bad' | undefined) => void;
}> = ({ message, onRegenerate, onEdit, onFeedback }) => {
  const { t } = useWorkspace();
  const isUser = message.sender === 'user';
  const isStreaming = Boolean(message.isStreaming);

  // Nothing yet to act on: a streaming bubble has no stable text to copy or regenerate.
  const showActions = !isStreaming && Boolean(message.content);

  return (
    <article
      className={`group flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
      data-testid={`message-${message.sender}`}
      data-message-id={message.id}
    >
      <p
        className={`mb-1 px-0.5 text-[11px] font-medium text-[var(--md-sys-color-on-surface-variant)] ${
          isUser ? 'text-end' : 'text-start'
        }`}
      >
        {isUser ? t.youLabel : t.assistantLabel}
      </p>

      {isUser ? (
        // The only background in the transcript. Deliberately subtle and never a full-width card.
        <div className="max-w-[85%] rounded-2xl rounded-ee-sm bg-[var(--md-sys-color-secondary-container)] px-3.5 py-2 text-[14px] leading-6 whitespace-pre-wrap text-[var(--md-sys-color-on-secondary-container)]">
          {message.content}
          {message.attachments && message.attachments.length > 0 && (
            <ul className="mt-1.5 flex flex-wrap gap-1">
              {message.attachments.map((file) => (
                <li
                  key={file.name}
                  className="rounded border border-[var(--md-sys-color-outline-variant)] px-1.5 py-0.5 text-[11px] opacity-80"
                >
                  {file.name}
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : (
        <div className="w-full max-w-[44rem] text-[var(--md-sys-color-on-surface)]">
          {isStreaming && !message.content ? (
            // Understated generation indicator: one breathing line, not a spinner or a skeleton.
            <span
              className="inline-flex items-center gap-1.5 py-1 text-[13px] text-[var(--md-sys-color-on-surface-variant)]"
              data-testid="generating"
              role="status"
              aria-live="polite"
            >
              <span
                className="h-1.5 w-1.5 animate-pulse rounded-full bg-[var(--md-sys-color-primary)] motion-reduce:animate-none"
                aria-hidden="true"
              />
              {t.streaming}
            </span>
          ) : (
            <RichText content={message.content} testId="message-content" />
          )}
          {!isStreaming && <ExecutionStatus message={message} />}
        </div>
      )}

      {showActions && (
        <ActionRow>
          {isUser ? (
            <>
              <IconButton label={t.editMessage} onClick={() => onEdit(message)} testId="message-edit">
                <Pencil size={13} />
              </IconButton>
              <CopyButton text={message.content} />
            </>
          ) : (
            <>
              <CopyButton text={message.content} />
              <IconButton label={t.regenerate} onClick={onRegenerate} testId="message-regenerate">
                <RefreshCw size={13} />
              </IconButton>
            </>
          )}
          {!isUser && <MoreMenu onFeedback={(feedback) => onFeedback(message, feedback)} />}
        </ActionRow>
      )}
    </article>
  );
};