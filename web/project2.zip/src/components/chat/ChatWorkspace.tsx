import React, { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown } from "lucide-react";
import { useWorkspace } from "../../context/WorkspaceContext";
import { ChatMessage } from "../../types/agent";
import { BotArtifact } from "../studio/BotArtifact";
import { BotPreviewPanel } from "../studio/BotPreviewPanel";
import { ChatHeader } from "../studio/ChatHeader";
import { Composer, type ComposerAttachment } from "../studio/Composer";
import { MessageItem } from "./MessageItem";

/** Within this many pixels of the bottom, the transcript is treated as "following along". */
const AT_TAIL = 160;

/**
 * The starting point: a question, one line of guidance, three ways in.
 *
 * Suggestions are plain text buttons rather than illustrated cards. They exist to remove the blank
 * page, and they leave the moment there is a real conversation to read.
 */
const EmptyState: React.FC<{ onPick: (prompt: string) => void }> = ({
  onPick,
}) => {
  const { t } = useWorkspace();
  const suggestions = [
    t.suggestionSupport,
    t.suggestionSales,
    t.suggestionKnowledge,
  ];

  return (
    <div
      className="flex min-h-[52vh] flex-col justify-center"
      data-testid="empty-state"
    >
      <h1 className="text-[22px] leading-8 font-semibold tracking-tight text-[var(--md-sys-color-on-surface)] sm:text-[26px]">
        {t.whatDoYouWantToBuild}
      </h1>
      <p className="mt-1.5 max-w-[34rem] text-[14px] leading-6 text-[var(--md-sys-color-on-surface-variant)]">
        {t.chatEmptyHint}
      </p>

      <ul className="mt-5 flex flex-wrap gap-2">
        {suggestions.map((suggestion) => (
          <li key={suggestion}>
            <button
              type="button"
              onClick={() => onPick(suggestion)}
              data-testid="suggestion"
              className="cursor-pointer rounded-full border border-[var(--md-sys-color-outline-variant)] px-3 py-1.5 text-[13px] text-[var(--md-sys-color-on-surface)] transition-colors hover:bg-[var(--md-sys-color-state-hover)]"
            >
              {suggestion}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

/**
 * The chat, as a bot-building session.
 *
 * The conversation *is* the interface: what you want, watching it get built, testing it and
 * refining it all happen in this one column. The preview is contextual — it opens beside the
 * transcript and collapses back into it — and nothing here is a dashboard.
 */
export const ChatWorkspace: React.FC = () => {
  const {
    t,
    activeConversation,
    sendMessage,
    isStreaming,
    isBuilding,
    stopStreaming,
    regenerateLastMessage,
    setMessageFeedback,
    artifact,
    artifactStatus,
    isPreviewOpen,
    openPreview,
  } = useWorkspace();

  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState<ChatMessage | null>(null);
  const [hasUnread, setHasUnread] = useState(false);
  const transcriptRef = useRef<HTMLDivElement>(null);
  const composerRef = useRef<HTMLTextAreaElement>(null);

  const messages = activeConversation?.messages ?? [];
  const isGenerating = isStreaming || isBuilding;

  /**
   * Follow the tail — but only when the user is already there.
   *
   * Someone reading back through an earlier answer is not asking to be dragged away by an incoming
   * token, so a new message that arrives while they are scrolled up raises the "new response"
   * affordance instead of moving the viewport.
   */
  const scrollToLatest = useCallback(() => {
    const node = transcriptRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, []);

  const lastMessageCount = useRef(messages.length);
  useEffect(() => {
    const node = transcriptRef.current;
    const grew = messages.length > lastMessageCount.current;
    lastMessageCount.current = messages.length;
    if (!node) return;

    const atTail =
      node.scrollHeight - node.scrollTop - node.clientHeight < AT_TAIL;
    if (grew && !atTail) setHasUnread(true);
    if (!grew || atTail) {
      setHasUnread(false);
      scrollToLatest();
    }
  }, [messages.length, scrollToLatest]);

  // A newly opened conversation is short: land on its end rather than making the user scroll.
  useEffect(scrollToLatest, [activeConversation?.id, scrollToLatest]);

  const submit = (value: string, attachments: ComposerAttachment[]) => {
    sendMessage(value, attachments);
    setEditing(null);
    setDraft("");
    setHasUnread(false);
    requestAnimationFrame(scrollToLatest);
  };

  const startEdit = (message: ChatMessage) => {
    setEditing(message);
    setDraft(message.content);
    document
      .querySelector<HTMLTextAreaElement>("[data-testid=composer-input]")
      ?.focus();
  };

  // The artifact belongs to the turn that built it, so it rides along with the last message rather
  // than floating somewhere the user has to go looking for it.
  const lastMessageId =
    messages.length > 0 ? messages[messages.length - 1].id : null;

  return (
    <div className="flex h-full min-h-0">
      <div className="flex min-w-0 flex-1 flex-col">
        <ChatHeader />

        <div className="relative min-h-0 flex-1">
          <div
            ref={transcriptRef}
            className="h-full overflow-y-auto px-4 sm:px-6"
            data-testid="transcript"
          >
            <div className="mx-auto w-full max-w-[46rem] py-6 sm:py-8">
              {messages.length === 0 ? (
                <EmptyState
                  onPick={(prompt) => {
                    setDraft(prompt);
                    document
                      .querySelector<HTMLTextAreaElement>(
                        "[data-testid=composer-input]",
                      )
                      ?.focus();
                  }}
                />
              ) : (
                <div className="space-y-7">
                  {messages.map((message) => (
                    <React.Fragment key={message.id}>
                      <MessageItem
                        message={message}
                        onRegenerate={regenerateLastMessage}
                        onEdit={startEdit}
                        onFeedback={(target, feedback) =>
                          setMessageFeedback(
                            target.id,
                            feedback ??
                              (target.feedback === "good" ? "bad" : "good"),
                          )
                        }
                      />
                      {artifact && message.id === lastMessageId && (
                        <BotArtifact
                          bot={artifact}
                          status={artifactStatus}
                          isPreviewOpen={isPreviewOpen}
                          onOpenPreview={openPreview}
                        />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              )}
            </div>
          </div>

          {hasUnread && (
            <div className="pointer-events-none sticky bottom-3 flex justify-center">
              <button
                type="button"
                onClick={() => {
                  setHasUnread(false);
                  scrollToLatest();
                }}
                data-testid="new-response"
                className="pointer-events-auto flex cursor-pointer items-center gap-1 rounded-full border border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)] py-1.5 ps-3 pe-3.5 text-[12px] font-medium text-[var(--md-sys-color-on-surface)] shadow-[0_1px_3px_rgba(0,0,0,0.16)] transition-colors hover:bg-[var(--md-sys-color-state-hover)]"
              >
                <ArrowDown size={13} />
                {t.newResponse}
              </button>
            </div>
          )}
        </div>

        <div className="shrink-0 px-4 pb-4 pt-1 sm:px-6">
          <div className="mx-auto max-w-[46rem]">
            <Composer
              value={draft}
              onChange={setDraft}
              onSubmit={submit}
              onStop={stopStreaming}
              placeholder={t.buildPlaceholder}
              isBusy={isGenerating}
            inputRef={composerRef}
              editing={
                editing
                  ? {
                      label: t.editMessage,
                      onCancel: () => {
                        setEditing(null);
                        setDraft("");
                      },
                    }
                  : null
              }
              testId="studio-input"
            />
          </div>
        </div>
      </div>

      {isPreviewOpen && artifact && (
        // Wide: the preview sits beside the transcript, and the composer keeps its place so nothing
        // jumps when it opens. Narrow: there is no room for both, so it takes over the screen —
        // same panel, same artifact, never a separate page.
        <div className="fixed inset-0 z-30 lg:static lg:z-auto lg:w-[min(40rem,42%)] lg:shrink-0">
          <BotPreviewPanel />
        </div>
      )}
    </div>
  );
};
